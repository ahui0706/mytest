+++
title = "Developing Plugins"
type = "docs"
[menu.docs]
parent = "plugins"
identifier = "developing"
weight = 3
+++
