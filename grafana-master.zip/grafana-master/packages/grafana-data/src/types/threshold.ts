export interface Threshold {
  value: number;
  color: string;
}
