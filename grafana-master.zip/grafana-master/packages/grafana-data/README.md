# Grafana Data Library

> **@grafana/data is currently in ALPHA**. Core API is unstable and can be a subject of breaking changes!

This package holds the root data types and functions used within Grafana.
